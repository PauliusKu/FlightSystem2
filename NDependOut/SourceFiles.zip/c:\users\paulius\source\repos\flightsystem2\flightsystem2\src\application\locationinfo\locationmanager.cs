﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FlightSystem.Api.Domain.Entities;
using FlightSystem.Api.Src.Application.Common;
using FlightSystem.Api.Src.Domain.Entities;

namespace FlightSystem.Api.Src.Application.AirportInfo
{
    public class LocationManager : ILocation
    {
        private IAirportData airportData = SetterData.GetAirportData();
        private ICountryData countryData = SetterData.GetCountryData();
        private IFlagImageData flagImageData = SetterData.GetFlagImageData();

        public Locations GetLocations()
        {
            return new Locations() { airports = GetAllAirports(), countries = GetAllCountries() };
        }

        public List<Country> GetAllCountries()
        {

            List<Country> countries = countryData.GetAll();

            flagImageData.AddFlagsToCountries(countries);

            return countries;
        }

        public List<Airport> GetAllAirports()
        {
            return airportData.GetAll();
        }
    }
}
