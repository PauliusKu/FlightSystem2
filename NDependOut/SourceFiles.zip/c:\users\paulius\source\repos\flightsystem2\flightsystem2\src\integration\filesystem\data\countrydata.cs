﻿using FlightSystem.Api.Domain.Entities;
using FlightSystem.Api.Src.Application.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightSystem.Api.Src.Integration.FileSystem.Data
{
    public class CountryData : ICountryData
    {
        public List<Country> GetAll()
        {
            throw new NotImplementedException();
        }
    }
}
