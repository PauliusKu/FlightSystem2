﻿using FlightSystem.Api.Src.Application.Common;
using FlightSystem.Api.Src.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightSystem.Api.Src.Integration.FileSystem.Data
{
    public class RouteData : IRouteData
    {
        public List<Route> GetRouteWith1Stop(TripParams tripParams)
        {
            throw new NotImplementedException();
        }

        public List<Route> GetRouteWith2Stop(TripParams tripParams)
        {
            throw new NotImplementedException();
        }
    }
}
